package java_28_Quan_li_Sach;

public class TacGia {
	private String tenTacGia;
	private Ngay NgaySinh;
	public TacGia(String tenTacGia, Ngay ngaySinh) {
		this.tenTacGia = tenTacGia;
		NgaySinh = ngaySinh;
	}
	public String getTenTacGia() {
		return tenTacGia;
	}
	public void setTenTacGia(String tenTacGia) {
		this.tenTacGia = tenTacGia;
	}
	public Ngay getNgaySinh() {
		return NgaySinh;
	}
	public void setNgaySinh(Ngay ngaySinh) {
		NgaySinh = ngaySinh;
	}
	
}
