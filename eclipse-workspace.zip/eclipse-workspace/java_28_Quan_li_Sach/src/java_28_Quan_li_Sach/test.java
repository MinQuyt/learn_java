package java_28_Quan_li_Sach;

public class test {
public static void main(String[] args) {
	Ngay Ngay1 = new Ngay(16, 5, 2003);
	Ngay Ngay2 = new Ngay(22,5,2003);
	Ngay Ngay3 = new Ngay(5 ,6,1973);
	
	TacGia TacGia1 = new TacGia("Tran Minh Quy",Ngay1);
	TacGia TacGia2 = new TacGia("MinQuyt",Ngay2);
	TacGia TacGia3 = new TacGia("Vu Thi Tiep",Ngay3);
	
	Sach Sach1 = new Sach("Nguoi toi co", 27000, 2016, TacGia1);
	Sach Sach2 = new Sach("Vung dat hac am",357000,2016, TacGia2);
	Sach Sach3 = new Sach("lam me",450000,2022,TacGia3);
	
	Sach1.inTenSach();
	Sach2.inTenSach();
	Sach3.inTenSach();
	
	System.out.println("Kiem tra nam xuat ban sach1 va sach 2:"+Sach1.KiemTraCungNam(Sach2));
	System.out.println("Kiem tra nam xuat ban sach2 va sach 3:"+Sach2.KiemTraCungNam(Sach3));
	System.out.println("Kiem tra nam xuat ban sach1 va sach 3:"+Sach1.KiemTraCungNam(Sach3));
	
	System.out.println("Sach1 sau khi giam 10%:"+Sach1.GiaSauKhiGiam(10));
	System.out.println("Sach2 sau khi giam 20%:"+Sach2.GiaSauKhiGiam(20));
	System.out.println("Sach3 sau khi giam 50%:"+Sach3.GiaSauKhiGiam(50));

}
}
