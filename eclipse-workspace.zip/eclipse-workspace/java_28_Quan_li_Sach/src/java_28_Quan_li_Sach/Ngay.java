package java_28_Quan_li_Sach;

public class Ngay {
private int ngay;
private int thang;
private int nam;
public Ngay(int d, int m, int y) {
	if(d>=1&& d<=31) {
	this.ngay = d;
	}else {
		this.ngay = 1;
	}
	if(m>=1 && m<=12) {
	this.thang = m;
	}else {
		this.thang =1;
	}
	if(y>=1) {
	this.nam = y;
	}else {
	this.nam =1;	
	}
}	
public int getNgay() {
	return ngay;
}
public void setNgay(int d) {
	this.ngay = d;
}
public int getThang() {
	return thang;
}
public void setThang(int m) {
	this.thang = m;
}
public int getNam() {
	return nam;
}
public void setNam(int y) {
	this.nam = y;
}
@Override
public String toString() {
	return "Ngay [ngay=" + ngay + ", thang=" + thang + ", nam=" + nam + "]";
}
	
}
