package java_22_Try_catch_final;

import java.util.Scanner;

public class vidu {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int n;
	System.out.println("Nhap so nguyen n:");
	
	try {
		n = sc.nextInt();
		System.out.println("so vua nhap la so nguyen");
	}catch(Exception e){
		System.out.println("de nghi nhap lai so nguyen");
	}finally{
		System.out.println("code nay auto chay ");
	}
}
}
