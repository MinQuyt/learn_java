package java_02;

public class khai_bao_bien {

}
