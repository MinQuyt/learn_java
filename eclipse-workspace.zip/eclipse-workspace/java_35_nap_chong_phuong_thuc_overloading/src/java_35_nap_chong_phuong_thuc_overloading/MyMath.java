package java_35_nap_chong_phuong_thuc_overloading;

public class MyMath {
	public int timMax(int a, int b) {
		if (a > b) {
			return a;
		} else {
			return b;
		}
	}
	public double timMax(double a, double b) {
		if (a > b) {
			return a;
		} else {
			return b;
		}
	}
	public double tinhTong(double a,double b) {
		return a+b;
	}
	public double tinhTong(double[] arr) {
		double tong = 0;
		for (int i = 0; i < arr.length; i++) {
			tong+=arr[i];
		}
		return tong;
	}
}