package java_35_nap_chong_phuong_thuc_overloading;

import java.util.Scanner;

public class test {
public static void main(String[] args) {
	Scanner sc =new Scanner(System.in);
	MyMath toan = new MyMath();
	System.out.println("Nhap vao 2 so nguyên a,b:");
	int a= sc.nextInt();
	int b=sc.nextInt();
	System.out.println("Nhâp vào 2 số thực c,d:");
	double c=sc.nextDouble();
	double d=sc.nextDouble();
	
	System.out.println("so lớn nhất trong a và b là :"+toan.timMax(a, b));
	System.out.println("so lớn nhất trong c và d là:"+ toan.timMax(c, d));
	System.out.println(" a + b=:"+toan.tinhTong(a, b));
	double arr[] = {1,2,3,4,5,6,7,8,9};
	System.out.println("tính tổng từ 1 đến 9:"+toan.tinhTong(arr));
}
}