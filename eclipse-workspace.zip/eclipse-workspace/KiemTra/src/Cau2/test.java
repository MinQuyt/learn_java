package Cau2;

import java.util.Scanner;

public class test {
public static void main(String[] args) {
	int so =1;
	while(so!=0) {
	ThoiDiemSanXuat thoiDiemSanXuat;
	//nhập giá trị
	Scanner sc = new Scanner(System.in);
	System.out.println("Nhập tên hàng hóa :");
	String tenHangHoa = sc.nextLine();
	System.out.println("Nhap mã số hàng hóa:");
	double maSoHangHoa = sc.nextDouble();
	System.out.println("Nhập ngày tháng năm sản xuất");
	int ngay = sc.nextInt();
	int thang = sc.nextInt();
	int nam = sc.nextInt();
	ThoiDiemSanXuat tg = new ThoiDiemSanXuat(ngay, thang, nam);
	System.out.println("Nhập số lượng sản phẩm:");
	long soLuongSanPham = sc.nextLong();
	System.out.println("Nhập giá thành sản phẩm:");
	double giaThanhMotSanPham = sc.nextDouble();
	HangHoa hh = new HangHoa(maSoHangHoa,tenHangHoa, tg,soLuongSanPham ,giaThanhMotSanPham);
	//hiển thị giá trị
	hh.xuat();
	//giảm giá:
	HangHoaSinhVien hhsv = new HangHoaSinhVien(maSoHangHoa, tenHangHoa, tg, soLuongSanPham, giaThanhMotSanPham);
	System.out.println("nhập số phần trăm bạn muốn giảm giá:");
	int x = sc.nextInt();
	System.out.println("giá tiền sau khi được giảm giá là:"+hhsv.GiamGia(x));
	System.out.println("Nhập số khác 0 để tiếp tục!");
	so = sc.nextInt();
}
}
}
