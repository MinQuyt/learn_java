package Cau2;

public class HangHoaSinhVien extends HangHoa {

	
	public HangHoaSinhVien(double maSoHangHoa, String tenHangHoa, ThoiDiemSanXuat thoiDiemSanXuat, long soLuongSanPham,
		double giaThanhMotSanPham) {
		super(maSoHangHoa, tenHangHoa, thoiDiemSanXuat, soLuongSanPham, giaThanhMotSanPham);
	}
	public double ThanhTien() {
		return 0.0;
	}
	
	public double GiamGia(double x) {
		return this.thanhtien()*(1-x/100);
	}

	}

