package Cau2;

public class HangHoa {
private double maSoHangHoa;
private String tenHangHoa;
private ThoiDiemSanXuat thoiDiemSanXuat;
private long soLuongSanPham;
private double giaThanhMotSanPham;
public HangHoa(double maSoHangHoa, String tenHangHoa, ThoiDiemSanXuat thoiDiemSanXuat, long soLuongSanPham,
		double giaThanhMotSanPham) {
	this.maSoHangHoa = maSoHangHoa;
	this.tenHangHoa = tenHangHoa;
	this.thoiDiemSanXuat = thoiDiemSanXuat;
	this.soLuongSanPham = soLuongSanPham;
	this.giaThanhMotSanPham = giaThanhMotSanPham;
}
public HangHoa(double maSoHangHoa2, int i, ThoiDiemSanXuat tg, Object object) {
	// TODO Auto-generated constructor stub
}
public double getMaSoHangHoa() {
	return maSoHangHoa;
}
public void setMaSoHangHoa(double maSoHangHoa) {
	this.maSoHangHoa = maSoHangHoa;
}
public String getTenHangHoa() {
	return tenHangHoa;
}
public void setTenHangHoa(String tenHangHoa) {
	this.tenHangHoa = tenHangHoa;
}
public ThoiDiemSanXuat getThoiDiemSanXuat() {
	return thoiDiemSanXuat;
}
public void setThoiDiemSanXuat(ThoiDiemSanXuat thoiDiemSanXuat) {
	this.thoiDiemSanXuat = thoiDiemSanXuat;
}
public long getSoLuongSanPham() {
	return soLuongSanPham;
}
public void setSoLuongSanPham(long soLuongSanPham) {
	this.soLuongSanPham = soLuongSanPham;
}
public double getGiaThanhMotSanPham() {
	return giaThanhMotSanPham;
}
public void setGiaThanhMotSanPham(double giaThanhMotSanPham) {
	this.giaThanhMotSanPham = giaThanhMotSanPham;
}
public double thanhtien() {
	return this.giaThanhMotSanPham*this.soLuongSanPham;
}
public void xuat() {
	System.out.println("Mã số hàng hóa:"+this.getMaSoHangHoa());
	System.out.println("tên hàng hóa:"+this.getTenHangHoa());
	System.out.println("thời gian sản xuất :"+this.getThoiDiemSanXuat());
	System.out.println("số lượng sản phẩm:"+this.getSoLuongSanPham());
	System.out.println("giá thành sản phẩm:"+this.getGiaThanhMotSanPham());
	System.out.println("thành tiền:"+this.thanhtien());
	
}
}
