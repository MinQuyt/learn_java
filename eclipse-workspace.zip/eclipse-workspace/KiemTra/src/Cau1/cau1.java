package Cau1;

public class cau1 {
boolean check(int n) {
	int dem =0,i=0;
	int a[] = new int[10];
	while(n>0) {
		a[dem] = n%10;
		n/=10;
		dem+=1;
	}
	for (int j = 0; j < dem/2; j++) {
		if(a[j] == a[dem-i-1]) {
			return true;
		}
		else {
			return false;
		}
	}
	return true;
}
}
