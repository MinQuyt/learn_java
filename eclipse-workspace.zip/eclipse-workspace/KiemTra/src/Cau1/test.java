package Cau1;

import java.util.Scanner;

public class test {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Nhập số lượng phần tử mảng:");
	int n= sc.nextInt();
	int a[] = new int[n];
	System.out.println("Nhập các phần tử mảng:");
	for (int i = 0; i < n; i++) {
		System.out.println("a["+i+"]=");
		a[i] = sc.nextInt();
	}
	cau1 c1 = new cau1();
	for (int i:a) {
		if(c1.check(i)) {
			System.out.println(i+"số thuận nghịch!");
		}else {
			System.out.println(i+"không phải số thuận nghịch!");
		}
	}
}
}
