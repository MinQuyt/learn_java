package java_37_on_tap_ke_thua_va_abstract;

public abstract class PhuongTienDiChuyen {
protected String loaiPhuongTien;
protected HangSanXuat hangSanXuat;
public PhuongTienDiChuyen(String loaiPhuongTien, HangSanXuat hangSanXuat) {
	this.loaiPhuongTien = loaiPhuongTien;
	this.hangSanXuat = hangSanXuat;
}
public String getLoaiPhuongTien() {
	return loaiPhuongTien;
}
public void setLoaiPhuongTien(String loaiPhuongTien) {
	this.loaiPhuongTien = loaiPhuongTien;
}
public HangSanXuat getHangSanXuat() {
	return hangSanXuat;
}
public void setHangSanXuat(HangSanXuat hangSanXuat) {
	this.hangSanXuat = hangSanXuat;
}
public String layTenHangSanXuat() {
	return this.hangSanXuat.getTenHangSanXuat();
}
public void khoiDong() {
	System.out.println("Bắt đầu khởi động!!!");
}
public void tangToc() {
	System.out.println("Bắt đầu tăng tốc độ lên 100Km/h");
}
public void tatMay() {
	System.out.println("Xe chuẩn bị ngừng , tiến hành tắt máy");
}
public abstract void vantoc();
}
