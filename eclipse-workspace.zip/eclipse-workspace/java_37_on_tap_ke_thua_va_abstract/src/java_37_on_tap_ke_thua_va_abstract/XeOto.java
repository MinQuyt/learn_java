package java_37_on_tap_ke_thua_va_abstract;

public class XeOto extends PhuongTienDiChuyen{
private String loaiNhienLieu;

public XeOto( HangSanXuat hangSanXuat, String loaiNhienLieu) {
	super("Xe động cơ 4 ký (ô tô) ", hangSanXuat);
	this.loaiNhienLieu = loaiNhienLieu;
}

public String getLoaiNhienLieu() {
	return loaiNhienLieu;
}

public void setLoaiNhienLieu(String loaiNhienLieu) {
	this.loaiNhienLieu = loaiNhienLieu;
}

@Override
public void vantoc() {
System.out.println("Vận tốc tối đa của oto là 500km/h");
}

}
