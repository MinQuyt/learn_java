package java_37_on_tap_ke_thua_va_abstract;

public class XeDap extends PhuongTienDiChuyen{



	public XeDap(String loaiPhuongTien, HangSanXuat hangSanXuat) {
		super(loaiPhuongTien, hangSanXuat);
	}

	@Override
	public void vantoc() {
System.out.println("Vận tốc tối đa của xe đạp là 100Km/h");		
	}
	

}
