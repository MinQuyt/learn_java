package java_37_on_tap_ke_thua_va_abstract;

public class MayBay extends PhuongTienDiChuyen{
	private String loaiNhienLieu;

	public MayBay( HangSanXuat hangSanXuat, String loaiNhienLieu) {
		super("máy bang thả bom", hangSanXuat);
		this.loaiNhienLieu = loaiNhienLieu;
	}

	public String getLoaiNhienLieu() {
		return loaiNhienLieu;
	}
	public void setLoaiNhienLieu(String loaiNhienLieu) {
		this.loaiNhienLieu = loaiNhienLieu;
	}
public void catCanh() {
	System.out.println("Chuẩn bị cất cánh");
}
public void haCanh() {
	System.out.println("Chuẩn bị hạ cánh");
}
@Override
public void vantoc() {
System.out.println("Vận tốc tối đa của may bay là 2000km/h");	
}
}
