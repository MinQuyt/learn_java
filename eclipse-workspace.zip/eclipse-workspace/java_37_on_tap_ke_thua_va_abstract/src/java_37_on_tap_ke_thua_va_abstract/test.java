package java_37_on_tap_ke_thua_va_abstract;

public class test {
public static void main(String[] args) {
	
HangSanXuat hang1 = new HangSanXuat("ASAMA", "Việt Nam");
HangSanXuat hang2 = new HangSanXuat("BenLey", "Đức");
HangSanXuat hang3 = new HangSanXuat("B52", "Mĩ");

MayBay mb = new MayBay( hang3, "xăng");
XeOto Ot = new XeOto( hang2, "Xăng hoặc xăng pha nhớt");
XeDap xd = new XeDap("xe đạp", hang1);

System.out.println(xd.getLoaiPhuongTien());
System.out.println("hãng sản xuất:"+xd.layTenHangSanXuat());
System.out.println("Quốc gia sản xuất:"+xd.hangSanXuat.getTenQuocGia());
xd.khoiDong();
xd.tangToc();
xd.vantoc();
System.out.println("-----------");

System.out.println(xd.getLoaiPhuongTien());
System.out.println("hãng sản xuất:"+Ot.layTenHangSanXuat());
System.out.println("Quốc gia sản xuất:"+Ot.hangSanXuat.getTenQuocGia());
System.out.println("loại nhiên liệu:"+Ot.getLoaiNhienLieu());
Ot.khoiDong();
Ot.tangToc();
Ot.vantoc();
Ot.tatMay();

System.out.println("-----------");

System.out.println(xd.getLoaiPhuongTien());
System.out.println("hãng sản xuất:"+mb.layTenHangSanXuat());
System.out.println("Quốc gia sản xuất:"+mb.hangSanXuat.getTenQuocGia());
System.out.println("loại nhiên liệu:"+mb.getLoaiNhienLieu());
mb.catCanh();
mb.tangToc();
mb.vantoc();
mb.haCanh();
}
}
