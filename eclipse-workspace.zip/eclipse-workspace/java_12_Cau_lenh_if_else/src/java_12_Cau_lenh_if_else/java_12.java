package java_12_Cau_lenh_if_else;

import java.util.Scanner;

public class java_12 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int a; 
	System.out.println("Nhap so a");
	a = sc.nextInt();
	if(a>0) {
		System.out.println(a+" là số duong");
		if(a%2==0) {
			System.out.println(a+" là số chan");
		}else {
			System.out.println(a+" là số le");
		}
	}else {
		System.out.println(a+" là số am");
		if(a%2==0) {
			System.out.println(a+" là số chan");
		}else {
			System.out.println(a+" là số le");
		}
	}	
}
}
