package java_12_Cau_lenh_if_else;

import java.util.Scanner;

public class GiaiPtBac1 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	float a , b , x ;
	System.out.println("Nhap so a v� b : ");
	a = sc.nextFloat();
	b = sc.nextFloat();
	if(a==0) {
		if(b==0) {
			System.out.println("Phuong trinh vo nghiem!");
		}else {
			System.out.println("Phuong trinh vo so nghiem!");
		}
	}else {
		x = (-b)/a;
		System.out.println("x= "+x);
	}
}
}
