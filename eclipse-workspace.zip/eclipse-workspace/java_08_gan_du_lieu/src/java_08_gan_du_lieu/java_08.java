package java_08_gan_du_lieu;

import java.util.Scanner;

public class java_08 {
public static void main(String[] args) {
	//khai báo dữ liệu
	float a,b;
	//nhập dữ liệu
	Scanner sc =new Scanner(System.in);
	System.out.println("Nhap a:");
	a= sc.nextFloat();
	System.out.println("Nhap b:");
	b= sc.nextFloat();
	//xuất và sử lí dữ liệu
	System.out.println("----------");
	System.out.println("a=b => a="+ (a=b));
	System.out.println("a+=b => a="+ (a+=b));
	System.out.println("a-=b => a="+ (a-=b));
	System.out.println("a*=b => a="+ (a*=b));
	System.out.println("a/=b => a="+ (a/=b));
	System.out.println("a%=b => a="+ (a%=b));
	}
}
