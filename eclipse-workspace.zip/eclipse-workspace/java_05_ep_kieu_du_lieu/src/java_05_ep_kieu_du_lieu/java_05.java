package java_05_ep_kieu_du_lieu;

public class java_05 {
public static void main(String[] args) {
	//ep kieu ngam dinh
	int a = 100; System.out.println("a= "+a);
	int b = 2;	System.out.println("b= "+b);
	
	float c=a; System.out.println("c= "+c);
	float d=b; System.out.println("d= "+d);
	
	//ep kieu tuong minh
	float e = 12.5f;
	float f = 3.14f;
	System.out.println("e= "+e);
	System.out.println("f= "+f);
	
	int g = (int)e;
	int h = (int)f;
	System.out.println("g= "+g);
	System.out.println("h= "+h);
	
	//ep kieu DL co ban va doi tuong
	int x = new Integer(b);
	System.out.println("x= "+x);
}
}
