package java_34_ghi_de_phuong_thuc;

public class ANIMAL {
protected String name;

public ANIMAL(String name) {
	this.name = name;
}
public void eat() {
	System.out.println("Tôi đang ăn.....");
}
public void makeSound() {
	System.out.println("Tôi đang kêu");
}
public void sleep() {
	System.out.println("tôi dang ngủ");
}
}
