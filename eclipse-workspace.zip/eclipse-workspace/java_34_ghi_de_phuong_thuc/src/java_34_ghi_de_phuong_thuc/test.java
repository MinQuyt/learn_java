package java_34_ghi_de_phuong_thuc;

public class test {
public static void main(String[] args) {
	
	Dog cho = new Dog();
	cho.eat();
	cho.makeSound();
	cho.sleep();

	Cat meo = new Cat();
	meo.eat();
	meo.makeSound();
	meo.sleep();
	
	Bird chim = new Bird();
	chim.eat();
	chim.makeSound();
	chim.sleep();
}	
}