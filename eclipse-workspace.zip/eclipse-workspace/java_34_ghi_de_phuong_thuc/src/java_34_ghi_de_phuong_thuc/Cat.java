package java_34_ghi_de_phuong_thuc;

public class Cat extends ANIMAL {
	public Cat( ) {
		super("Cat");
	}
	@Override
public void eat() {
	System.out.println("Măm măm");
}
	@Override
public void makeSound() {
System.out.println("meo meo");	
}
}
