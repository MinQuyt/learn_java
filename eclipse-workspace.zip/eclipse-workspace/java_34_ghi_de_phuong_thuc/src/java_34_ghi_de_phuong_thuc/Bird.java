package java_34_ghi_de_phuong_thuc;

public class Bird extends ANIMAL {
	public Bird( ) {
		super("Bird");
	}
	@Override
public void eat() {
	System.out.println("mổ mổ");
}
	@Override
public void makeSound() {
System.out.println("chiếp chiếp");	
}
}
