package java_34_ghi_de_phuong_thuc;

public class Dog extends ANIMAL {

	public Dog( ) {
		super("Dog");
	}

	@Override
	public void eat() {
			System.out.println("h�p h�p");
		}
		
	@Override
	public void makeSound() {
			System.out.println("g�u g�u");			
	}


}
