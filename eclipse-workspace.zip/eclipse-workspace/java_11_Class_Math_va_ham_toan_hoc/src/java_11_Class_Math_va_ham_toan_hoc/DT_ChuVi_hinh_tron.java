package java_11_Class_Math_va_ham_toan_hoc;

import java.util.Scanner;

public class DT_ChuVi_hinh_tron {
public static void main(String[] args) {
	double r,CV,DT;
	Scanner sc = new Scanner(System.in);
	System.out.println("Nhap bán kính r:");
	r = sc.nextDouble();
	CV = 2*(r)*(Math.PI);
	DT = Math.pow(r, 2) * Math.PI;
	System.out.println("Chu vi = "+CV);
	System.out.println("Dien tich = "+DT);
}
}
