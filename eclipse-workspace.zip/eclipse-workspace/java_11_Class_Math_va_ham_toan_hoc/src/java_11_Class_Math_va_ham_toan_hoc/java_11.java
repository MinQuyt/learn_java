package java_11_Class_Math_va_ham_toan_hoc;

import java.util.Scanner;

public class java_11 {
	public static void main(String[] args) {
		double a,b;
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap a:");
		a = sc.nextDouble();
		System.out.println("Nhap b:");
		b = sc.nextDouble();
		//ham tri tuyet doi abs
		System.out.println("|a|= " + Math.abs(a));
		//ham tìm min , max
		System.out.println("min(a,b)= "+ Math.min(a, b));
		System.out.println("max(a,b)= " + Math.max(a,b));
		//hàm floor , ceil
		System.out.println("ceil(a)= "+ Math.ceil(a));
		System.out.println("floor(a)= "+ Math.floor(a));
		//hàm căn bậc hai sqrt
		System.out.println("sprt(a)= "+ Math.sqrt(a));
		//hà mũ pow
		System.out.println("a^b=" + Math.pow(a, b));
	}
}
