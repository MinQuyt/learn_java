package java_23_Mydate;

import java.security.PublicKey;
import java.util.Scanner;
//tao class MyDate
public class MyDate {
	private int day;
	private int month;
	private int year;
//Tao con tro (constructor) MyDate , con tro phai cung ten voi ten Class 
public MyDate(int d , int m , int y) {
	this.day = d;
	this.month = m;
	this.year = y;
}
// goi xuat ngay , xuat thang, xuat nam
public void printDay() {
	System.out.println("Day="+this.day);	
}
public void printMonth() {
	System.out.println("Month="+this.month);
}
public void printYear() {
	System.out.println("Year="+this.year);
}
public void printDate() {
	System.out.println("Date:"+this.day+"-"+this.month+"-"+this.year);
}
//goi ham main
public static void main(String[] args) {
	int so=1;
	while(so!=0) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Nhap ngay thang nam:");
	int ngay = sc.nextInt();
	int thang= sc.nextInt();
	int nam = sc.nextInt();
	MyDate md = new MyDate(ngay, thang, nam);
	md.printDay();
	md.printMonth();
	md.printYear();
	md.printDate();
	System.out.println("Nhap 1 de tiep tuc , 0 de dung lai");
	so = sc.nextInt(); 
}
}
}
