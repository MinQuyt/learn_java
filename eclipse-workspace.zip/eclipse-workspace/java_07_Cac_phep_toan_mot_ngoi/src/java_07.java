
public class java_07 {
public static void main(String[] args) {
	//khai báo du lieu
	int a=5; 
	boolean b = false;
	//xu li du lieu
	System.out.println("-a => "+ (-a));
	System.out.println("+a => "+ (+a));
	System.out.println("!b => "+ (!b));
	System.out.println("---------");
	System.out.println("a = "+a);
	System.out.println("++a = "+ ++a); // hiện giá trị tăng a lên 1
	System.out.println("a++ = "+ a++); // hien gia tri cũ ( o dong 13 ) roi moi tăng lên 1
	System.out.println("a = "+a); //hiện giá trị sau khi đã tăng ở dòng 14
	System.out.println("--a = "+ --a);//hien giá trị giảm đi 1
	System.out.println("a-- = "+ a--);//hien gia trị cũ ( ở dòng 16) rồi mới giảm đi 1 
	System.out.println("a= "+ a); // hien giá trị sau khi được giảm ở dòng 17
	}
}
