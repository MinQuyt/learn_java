package java_33_ke_thua_tiep_p3;

public class cat extends ANIMAL {

	public cat( ) {
		super("Cat");
		// TODO Auto-generated constructor stub
	}
	public void meow() {
		System.out.println("meo meo!");
	}
}
