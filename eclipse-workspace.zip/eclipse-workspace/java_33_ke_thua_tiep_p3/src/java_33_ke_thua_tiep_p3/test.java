package java_33_ke_thua_tiep_p3;

public class test {
public static void main(String[] args) {
	//gọi con chó
	Dog cho = new Dog();
	cho.eat();
	cho.bark();
	//gọi con mèo
	cat meo = new cat();
	meo.eat();
	meo.meow();
	//gọi con chim
	Birth chim = new Birth();
	chim.eat();
	chim.fly();
	
}
}
