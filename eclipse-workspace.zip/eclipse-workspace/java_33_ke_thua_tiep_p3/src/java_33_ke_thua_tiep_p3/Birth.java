package java_33_ke_thua_tiep_p3;

public class Birth extends ANIMAL{

	public Birth() {
		super("Bỉth");
	}
public void fly() {
	System.out.println("Tôi đang bay!");
}
}
