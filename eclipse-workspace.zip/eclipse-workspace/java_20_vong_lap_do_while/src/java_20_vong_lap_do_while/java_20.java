package java_20_vong_lap_do_while;

import java.util.Scanner;

public class java_20 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int n;
	do {
		System.out.println("Nhap so lon hon khac 0 de tiep tuc:");
		n = sc.nextInt();
		
	}while(n!=0);
}
}
