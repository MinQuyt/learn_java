package java_02_khai_bao_bien;

public class java_02 {
	public static void main(String[] args) {
		String Ten = "Tran Minh Quy ";
		System.out.println(Ten + "Ten: " +Ten + "dep trai");
	}
}
