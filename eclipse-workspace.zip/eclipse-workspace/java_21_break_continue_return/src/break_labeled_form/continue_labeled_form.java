package break_labeled_form;

public class continue_labeled_form {
	public static void main(String[] args) {
	thoat_ra:	for (int i = 2; i < 9; i++) { // cai thoat_ra chinh la labeled 
					for (int j =1;  j < 10; j++) {
						if(i>5)
				continue thoat_ra; //goi laij cai labeled
			System.out.println(i + "x" +j+ "=" + i*j );	
		}
	System.out.println("-----------");
	}
}
}
