package break_labeled_form;

public class Continue_unlabeled_form {
public static void main(String[] args) {
	int max=100;
	for (int i = 0; i < max; i++) {
		if(i<50)
			continue; // bo qua luon nhung so nho hon 50
		System.out.println(i);//xuar ra nhhung so lon ho 50	
	}
}
}
