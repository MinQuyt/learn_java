package java_03_khai_bao_hang_so;

public class java_03 {
	public static void main(String[] args) {
		final double Pi = 3.14 ; 
		System.out.println("pi="+Pi);
//		Pi = 12.2; se bi loi code 
	}
}
