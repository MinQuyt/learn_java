package java_19_chuyen_nhi_phan_sang_thap_phan;

import java.util.Scanner;

public class java_19 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int n;
	System.out.println("nhap so n bat ki :");
	n = sc.nextInt();
	String Chuyendoi = "";
	while(n>0) {
		Chuyendoi = (n%2)+Chuyendoi;
		n/=2;
	}
	System.out.println("so sau khi chuyen ra nhi phan : " +Chuyendoi);
}
}
