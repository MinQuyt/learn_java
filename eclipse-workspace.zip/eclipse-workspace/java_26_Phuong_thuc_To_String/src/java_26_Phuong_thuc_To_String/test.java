package java_26_Phuong_thuc_To_String;

import java.util.Scanner;

public class test {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int d , m ,y;
	System.out.println("Nhập ngày , tháng , năm :");
	d=sc.nextInt();
	m= sc.nextInt();
	y = sc.nextInt();
	MyDate md = new MyDate(d, m, y);
	System.out.println(md);
	System.out.println("Nhap ngày , tháng , năm muốn thay đổi:");
	d=sc.nextInt();
	m= sc.nextInt();
	y = sc.nextInt();
	md.setDay(d);
	md.setMonth(m);
	md.setYear(y);
	System.out.println(md);
}
}
