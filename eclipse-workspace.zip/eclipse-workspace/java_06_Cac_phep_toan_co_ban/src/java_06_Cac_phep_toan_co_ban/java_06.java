package java_06_Cac_phep_toan_co_ban;
import java.util.Scanner;
public class java_06 {
public static void main(String[] args) {
	int a,b,tong,hieu,tich,Sodu;
	double thuong;
	//nhap du lieu
	Scanner sc = new Scanner(System.in);
	System.out.println("Nhap a:");
	a = sc.nextInt();
	System.out.println("Nhap b:");
	b = sc.nextInt();
	//su li du lieu
	tong = a+b;
	hieu = a-b;
	tich = a*b;
	thuong = (double)a/b;
	Sodu = a%b;
	//Xuat du lieu
	System.out.println("----------");
	System.out.println(a+" + "+b+" = "+tong);
	System.out.println(a+" - "+b+" = "+hieu);
	System.out.println(a+" x "+b+" = "+tich);
	System.out.println(a+" : "+b+" = "+thuong);
	System.out.println(a+" % "+b+" = "+Sodu);
	System.out.println("----------");
	}
}
