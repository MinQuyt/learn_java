package java_10_Toan_tu_dieu_kien;

import java.util.Scanner;

public class java_10 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Nhap a:");
	int a = sc.nextInt();
	//Toan tu dieu kien
	String KetQua = (a%2==0)? "số chan" : "số le" ;
	System.out.println(a+" là "+ KetQua);
}
}
