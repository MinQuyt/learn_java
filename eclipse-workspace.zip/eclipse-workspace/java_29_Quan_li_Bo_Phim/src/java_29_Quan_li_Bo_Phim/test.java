package java_29_Quan_li_Bo_Phim;

public class test {
public static void main(String[] args) {
	NgayChieu ngay1 = new NgayChieu(22, 5, 2003);
	NgayChieu ngay2 = new NgayChieu(16, 5, 2003);
	NgayChieu ngay3 = new NgayChieu(19, 5, 2003);
	
	HangSanXuat hangSanXuat1 = new HangSanXuat("Quý Studio" , "VietNam");
	HangSanXuat hangSanXuat2 = new HangSanXuat("hang 2", "USA");
	HangSanXuat hangSanXuat3 = new HangSanXuat("hang 3", "Japanese");
	
	BoPhim bophim1 = new BoPhim("return 1997", 1997, hangSanXuat1, 65000, ngay1);
	BoPhim bophim2 = new BoPhim("Avenger", 1993, hangSanXuat2, 85000, ngay2);
	BoPhim bophim3 = new BoPhim("Star War", 1960, hangSanXuat3, 47000, ngay3);

	System.out.println("So sanh gia ve bophim 1 re hon giá vé bộ phim 2:"+bophim1.kiemTraGiaVeReHon(bophim2));
	System.out.println("So sanh gia ve bophim 2 re hon giá vé bộ phim 3:"+bophim2.kiemTraGiaVeReHon(bophim3));
	System.out.println("So sanh gia ve bophim 3 re hon giá vé bộ phim 1:"+bophim3.kiemTraGiaVeReHon(bophim1));

	System.out.println("ten hang san xuat phim 1:"+bophim1.layTenHangSanXuatPhim());
	System.out.println("ten hang san xuat phim 2:"+bophim2.layTenHangSanXuatPhim());
	System.out.println("ten hang san xuat phim 3:"+bophim3.layTenHangSanXuatPhim());

	System.out.println("Gia ve phim 1 sau khi giam gia khuyen mai 10%:"+bophim1.giaSauKhuyenMai(10));
	System.out.println("Gia ve phim 2 sau khi giam gia khuyen mai 20%:"+bophim2.giaSauKhuyenMai(20));
	System.out.println("Gia ve phim 3 sau khi giam gia khuyen mai 50%:"+bophim3.giaSauKhuyenMai(50));

}
}
