package test;

import code.Infor;
public class test {
	private Infor infor;
	public void method() {
	//this.infor.a => kiểu private không truy cập được ở package khác
	//this.infor.b =>kiểu int không truy cập được ở package khác
	//this.infor.c => kiểu protected không truy cập được ỏ package khác trừ khi dùng extends 
	this.infor.d =4; //=>kiểu public có thể truy cập được ở package khác
	}
}
