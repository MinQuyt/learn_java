package test;

import code.Infor;

public class sub_infor2 extends Infor {
	public Infor infor;
public void method() {
	//super.a => kiểu private không truy cập được ỏ class con khác package 
	//super.b =>kiểu int không truy suất được vì khác class
	//this.infor.b => không được nốt
	super.c =3; //=> kiểu protected có thể truy cập ở class con trong package khác
	this.c=3; //vẫn được
	super.d =4; // => kiểu public có thể truy suất ở class con trong package khác
	this.infor.d =4; // => vẫn được
	this.d =4; //=> cũng được
}
}
