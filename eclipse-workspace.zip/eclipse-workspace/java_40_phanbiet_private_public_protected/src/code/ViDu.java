package code;

public class ViDu {
	private Infor infor;
	public void method() {
		//this.infor.a =>kiểu private khong truy suat được ở class cùng package 
		this.infor.b =2 ; //=> kiểu int truy cập được ở class khác cùng package
		this.infor.c =3; //kiểu protected có thể truy suất ở class khác cùng package
		this.infor.d =4; // kiểu public có thể truy suất được ỏ class khác cùng package
	}
}
