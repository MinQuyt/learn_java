package code;

public class Infor {
	private int a;
	int b;
	protected int c;
	public int d;
	
	public void method() {
		this.a =1;
		this.b=2;
		this.c = 3;
		this.d =4;
	}
}
