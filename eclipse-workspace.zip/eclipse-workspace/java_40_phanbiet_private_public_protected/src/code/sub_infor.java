package code;

public class sub_infor extends Infor {

	public void method() {
		//super.a => kiểu private không truy cập được ở class con cùng package
		super.b =2; //=> kiểu int truy cập được ở class con => vì chung package ( khác package thì int không truy suất được)
		super.c =3; //=> kiểu protected truy cập được ở class con cùng package
		super.d =4; //=>kiểu public có thể truy cập được ở class con cùng package   
	}
}
