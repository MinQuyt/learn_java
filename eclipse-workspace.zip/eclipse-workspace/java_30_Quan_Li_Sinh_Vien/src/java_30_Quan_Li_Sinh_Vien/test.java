package java_30_Quan_Li_Sinh_Vien;

public class test {
	public static void main(String[] args) {
	//Gọi class NgaySinh và cho giá trị ngay1 , ngay2 , ngay3
NgaySinh ngay1 = new NgaySinh(25, 10, 2003);
NgaySinh ngay2 = new NgaySinh(16, 5, 2003);
NgaySinh ngay3 = new NgaySinh(16, 5, 2003);
	//Gọi class Lop và cho giá chị cho đối tượng lop1 lop2 lop 3
Lop lop1 = new Lop("CNTT K1504", "Công nghệ thông tin");
Lop lop2 = new Lop("NNA K1501", "Ngôn ngữ anh");
Lop lop3 = new Lop("QTKD K1502", "Quản trị kinh doanh");

SinhVien sinhvien1 = new SinhVien("Trần Ngoc linh","SV001", ngay1, 3.6, lop1);
SinhVien sinhvien2 = new SinhVien("Tran Minh Quy", "SV002", ngay2, 9.98, lop2);
SinhVien sinhvien3 = new SinhVien("Pham Mai Huong", "SV003", ngay3, 8.7, lop3);

System.out.println("tên khoa sinhvien1 theo học :"+sinhvien1.tenKhoaSinhVienTheoHoc());
System.out.println("tên khoa sinhvien2 theo học :"+sinhvien2.tenKhoaSinhVienTheoHoc());
System.out.println("tên khoa sinhvien3 theo học :"+sinhvien3.tenKhoaSinhVienTheoHoc());

System.out.println("kiểm tra học sinh 1 có đậu hay không:"+sinhvien1.kiemTraHocsinhCoDauHayKhong());;
System.out.println("kiểm tra học sinh 2 có đậu hay không:"+sinhvien2.kiemTraHocsinhCoDauHayKhong());;
System.out.println("kiểm tra học sinh 3 có đậu hay không:"+sinhvien3.kiemTraHocsinhCoDauHayKhong());;

System.out.println("Kiểm tra sinhvien1 có ngày sinh giông sinhvien2 không:"+sinhvien1.KiemTraNgaySinhGiongNhau(sinhvien2));
System.out.println("Kiểm tra sinhvien2 có ngày sinh giông sinhvien3 không:"+sinhvien2.KiemTraNgaySinhGiongNhau(sinhvien3));
System.out.println("Kiểm tra sinhvien3 có ngày sinh giông sinhvien1 không:"+sinhvien3.KiemTraNgaySinhGiongNhau(sinhvien1));

	}
}
