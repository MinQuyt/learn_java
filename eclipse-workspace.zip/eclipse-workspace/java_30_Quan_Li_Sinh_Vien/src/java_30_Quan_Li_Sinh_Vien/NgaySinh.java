package java_30_Quan_Li_Sinh_Vien;

import java.util.Objects;

public class NgaySinh {
private int day;
private int month;
private int year;
public NgaySinh(int day, int month, int year) {
	if(this.day>=1 && this.day<=31) {
		this.day = day;
		}else { 
			this.day = 1;
		}
		if(this.month >=1 && this.month <=12) {
		this.month = month;
		}else {
			this.month =1;
		}
		if(this.year >=0) {
		this.year = year;
		}else {
			this.year =1;
		}	
}
	public int getDay() {
		return this.day;
	}
	public void setDay(int d) {
		if(d>=1 && d<=31)
			this.day = d;
	}
	public int getMonth() {
		return this.month;
	}
	public void setMonth(int m) {
		if(m>=1 && m<=12)
			this.month = m;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int y) {
		if(y>=1)
			this.year = y;
	}
	
	@Override
	public String toString() {
		return this.day + "/" + this.month + "/"+this.year;
	}
@Override
public int hashCode() {
	return Objects.hash(day, month, year);
}
@Override
public boolean equals(Object obj) {
	//nếu đối tượng this bằng đối tượng obj thì trả về true
	if (this == obj)
		return true;
	//nếu đối tượng obj rỗng thì trả về false
	if (obj == null)
		return false;
	//nếu đối tượng tại class khác với đối tượng obj tại class thì trả về false
	if (getClass() != obj.getClass())
		return false;
	//ta gấn đối tượng other == đối tượng obj
	NgaySinh other = (NgaySinh) obj;
	if(this.day != other.day) 
		return false;
	if(this.month != other.month)
		return false;
	if(this.year != other.year)
		return false;
	return true;
}
}
