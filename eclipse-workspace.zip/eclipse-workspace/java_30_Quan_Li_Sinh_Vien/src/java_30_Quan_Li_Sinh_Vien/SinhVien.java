package java_30_Quan_Li_Sinh_Vien;

public class SinhVien {
private String hoVaten;
private String maSoSinhVien;
private NgaySinh ngay;
private double diemTrungBinh;
private Lop lop;
public SinhVien(String hoVaten, String maSoSinhVien, NgaySinh ngay, double diemTrungBinh, Lop lop) {
	this.hoVaten = hoVaten;
	this.maSoSinhVien = maSoSinhVien;
	this.ngay = ngay;
	this.diemTrungBinh = diemTrungBinh;
	this.lop = lop;
}
public String getHoVaten() {
	return hoVaten;
}
public void setHoVaten(String hoVaten) {
	this.hoVaten = hoVaten;
}
public String getMaSoSinhVien() {
	return maSoSinhVien;
}
public void setMaSoSinhVien(String maSoSinhVien) {
	this.maSoSinhVien = maSoSinhVien;
}
public NgaySinh getNgay() {
	return ngay;
}
public void setNgay(NgaySinh ngay) {
	this.ngay = ngay;
}
public double getDiemTrungBinh() {
	return diemTrungBinh;
}
public void setDiemTrungBinh(double diemTrungBinh) {
	this.diemTrungBinh = diemTrungBinh;
}
public Lop getLop() {
	return lop;
}
public void setLop(Lop lop) {
	this.lop = lop;
}
public String tenKhoaSinhVienTheoHoc() {
	return this.lop.getTenKhoa();
}
public boolean kiemTraHocsinhCoDauHayKhong() {
	return diemTrungBinh >= 5;
}
public boolean KiemTraNgaySinhGiongNhau(SinhVien SvKhac) {
	return this.ngay.equals(SvKhac.ngay);
}
}