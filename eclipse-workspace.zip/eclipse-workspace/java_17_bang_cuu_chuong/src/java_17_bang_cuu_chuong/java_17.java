package java_17_bang_cuu_chuong;

public class java_17 {
public static void main(String[] args) {
	for (int i = 1; i < 11; i++) {
		for (int j = 1; j < 11; j++) {
			System.out.println(i +"x" +j +"=" + i*j );
			}
		System.out.println("-----------");
 		}
	}
}
