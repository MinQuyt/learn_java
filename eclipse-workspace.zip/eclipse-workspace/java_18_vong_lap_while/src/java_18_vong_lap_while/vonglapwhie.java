package java_18_vong_lap_while;

import java.util.Scanner;

public class vonglapwhie {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int thang ,nam,so = 1 ;
	while(so!=0) {
	System.out.println("Nhap thang và năm : ");
	thang = sc.nextInt();
	nam = sc.nextInt();
	switch(thang) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			System.out.println("thang co 31 ngay!");
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			System.out.println("thang co 30 ngay!");
			break;
		case 2:
			if((nam%4==0 && nam%100!=0) || (nam%400==0)) {
				System.out.println("thang có 29 ngày!");
			}else {
				System.out.println("thang co 28 ngay!");
			}
			break;
	}
	System.out.println("nhap so bang 1 de tiep tuc , nhap 0 de dung lai:");
	so = sc.nextInt();
	}
	}
}