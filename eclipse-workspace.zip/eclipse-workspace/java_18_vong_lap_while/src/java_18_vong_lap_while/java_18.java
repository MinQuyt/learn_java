package java_18_vong_lap_while;

public class java_18 {

}
