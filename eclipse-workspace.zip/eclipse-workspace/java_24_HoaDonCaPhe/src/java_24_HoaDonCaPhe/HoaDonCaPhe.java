package java_24_HoaDonCaPhe;

public class HoaDonCaPhe {
	private String tenLoaiCaPhe;
	private double giatien1Kg;
	private double KhoiLuong;
//Tao con tro Contructor , Constructor name trùng với Class name
public HoaDonCaPhe(String ten , double gia , double KL) {
	this.tenLoaiCaPhe = ten;
	this.giatien1Kg = gia;
	this.KhoiLuong = KL;	
}
//Tao phương thức ( phương thức ở java tương đương với hàm con ở C ) tính tổng tiền 
public double TinhTongTien() {
	return this.giatien1Kg * this.KhoiLuong;
}
public boolean KTTongTienLonHon500(){
	return this.TinhTongTien() > 500000;
}
public double GiamGia(double PTGiamGia) {
	if( this.TinhTongTien() > 500000 ){
	return this.TinhTongTien()*PTGiamGia/100;
}
	else {
		return 0;
	}
		
}
public double TienSauGiamGia(double PTGiamGia) {
	return this.TinhTongTien() - this.GiamGia(PTGiamGia);
}
}
