package java_24_HoaDonCaPhe;

import java.util.Scanner;

public class test {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int so=1;
	while(so!=0) {
	System.out.println("Nhap ten Cafe, giá tien , so luong: ");
	String ten = sc.nextLine();
	double giatien = sc.nextDouble();
	double soluong = sc.nextDouble();
	System.out.println("Nhap phần trăm giảm giá nếu hóa đơn trên 500k");
	double PTGiamGia = sc.nextDouble();
//Gọi lại Class HoaDonCaPhe và phương thức HoaDonCaPhe bên kia và cho các phần tử ten , giatien , soluong bên trên vào
	HoaDonCaPhe hd = new HoaDonCaPhe(ten, giatien,soluong); 
	System.out.println("Cafe của bạn:"+ten+" số lượng :"+soluong+" Giá tiền:"+giatien);
	System.out.println("Tong tien="+hd.TinhTongTien());
	System.out.println("Kiem tra tong tien lon hon 500k "+hd.KTTongTienLonHon500());
	System.out.println("Số tiền được giảm giá là:"+hd.GiamGia(PTGiamGia));
	System.out.println("Số tiền phải trả sau khia giảm giá là: "+hd.TienSauGiamGia(PTGiamGia));
	System.out.println("nhập số khác 0 để tiếp tục:");
	so=sc.nextInt();
	}
}
}
