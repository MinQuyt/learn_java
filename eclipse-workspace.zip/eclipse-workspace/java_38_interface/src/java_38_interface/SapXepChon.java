package java_38_interface;

public class SapXepChon implements SapXepInterface {

	@Override
	public void SapXepTang(double[] arr) {
	int i ,j ,min_idx;
	for(i=0;i<arr.length;i++) {
		min_idx=i;
		for(j=i+1;j<arr.length;j++) {
			if(arr[j]<arr[min_idx]) {
				min_idx = j;
			}
		}
		double temp =arr[min_idx];
		arr[min_idx] = arr[i];
		arr[i] = temp;
	}
	}

	@Override
	public void SapXepGiam(double[] arr) {
		int i ,j ,min_idx;
		for(i=0;i<arr.length;i++) {
			min_idx=i;
			for(j=i+1;j<arr.length;j++) {
				if(arr[j] > arr[min_idx]) {
					min_idx = j;
				}
			}
			double temp =arr[min_idx];
			arr[min_idx] = arr[i];
			arr[i] = temp;
		}
	}
}