package java_38_interface;

public interface MayTinhBoTuiInterface {
//public  double cong(double a, double b); // dòng này với dòng dưới i hệt nhau , có abstract hay không cũng thế vì interface tất cả các phương thức đều là abstract
public abstract double cong(double a,double b);

public double tru(double a, double b);

public double nhan(double a , double b);

public double chia(double a , double b);

}

