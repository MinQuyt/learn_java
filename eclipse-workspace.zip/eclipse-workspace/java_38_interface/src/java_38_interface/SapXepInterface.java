package java_38_interface;

public interface SapXepInterface {

public void SapXepTang(double[] arr);

public void SapXepGiam(double[] arr);	
}
