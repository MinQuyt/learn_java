package java_38_interface;

import java.util.Scanner;

public class test {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);	
	System.out.println("test câu a:");
	System.out.println("---------");	
	System.out.println("nhập 2 số a và b:");
	double a=sc.nextDouble();
	double b = sc.nextDouble();
	//casio
	MayTinhCasioFX500 Mtcs = new MayTinhCasioFX500() ;
	System.out.println("a+b="+Mtcs.cong(a, b));
	System.out.println("a-b="+Mtcs.tru(a, b));
	System.out.println("a*b="+Mtcs.nhan(a, b));
	System.out.println("a/b="+Mtcs.chia(a, b));
	System.out.println("a/b="+Mtcs.chia(a, b));
	
	//vinacal
	MayTinhVinaCal500 Mtvnc = new MayTinhVinaCal500();
	System.out.println("a+b="+Mtvnc.cong(a, b));
	System.out.println("a-b="+Mtvnc.tru(a, b));
	System.out.println("a*b="+Mtvnc.nhan(a, b));
	System.out.println("a/b="+Mtvnc.chia(a, b));
	System.out.println("---------");
	System.out.println("test câu b:");
	double arr1[] = new double[] {2 ,4,5,9,7,5,4,6,3};
	double[] arr2 = new double[] {1,8,7,5,4,6,9};
	SapXepChen SXChen = new SapXepChen();
	System.out.println("SapXepchen:");
	SXChen.SapXepTang(arr1);
	for (int i = 0; i < arr1.length; i++) {
		System.out.print(arr1[i]+" ");
	}
	System.out.println();
	SXChen.SapXepGiam(arr2);
	for (int i = 0; i < arr2.length; i++) {
		System.out.print(arr2[i]+" ");
	}
	System.out.println();
	SapXepChon SXChon = new SapXepChon();
	System.out.println("SapXepChon:");
	SXChon.SapXepTang(arr2);
	for (int i = 0; i < arr2.length; i++) {
		System.out.print(arr2[i]+" ");
	}
	System.out.println();
	SXChon.SapXepGiam(arr1);
	for (int i = 0; i < arr1.length; i++) {
		System.out.print(arr1[i]+" ");
}
	System.out.println("test câu c:");
	PhanMemMayTinh PMMT = new PhanMemMayTinh();
	System.out.println("a+b="+PMMT.cong(a, b));
	System.out.println("a-b="+PMMT.tru(a, b));
	System.out.println("a*b="+PMMT.nhan(a, b));
	System.out.println("a/b="+PMMT.chia(a, b));
	PMMT.SapXepTang(arr1);
	for (int i = 0; i < arr1.length; i++) {
		System.out.print(arr1[i]+" ");
	}
	System.out.println();
	PMMT.SapXepGiam(arr2);
	for (int i = 0; i < arr2.length; i++) {
		System.out.print(arr2[i]+" ");
	}
}
}