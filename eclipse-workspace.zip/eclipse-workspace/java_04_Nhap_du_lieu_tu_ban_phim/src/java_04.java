import java.util.Scanner;
public class java_04 {
	//Khai bao main
	public static void main(String[] args) {
		//Khai bao Scanner
		Scanner Sv = new Scanner(System.in);
			//nhap du lieu vao Bien
			System.out.println("Nhap vao ho va ten:");
			String HoVaTen  = Sv.nextLine();
			System.out.println("Nhap tuoi");
			int tuoi = Sv.nextInt();
			System.out.println("Nhap ma sinh vien:");
			long MSV = Sv.nextLong();
			System.out.println("Nhap so diem thi:");
			float Diem = Sv.nextFloat();
			//Xuat du lieu ra bang Console
			System.out.println("-------------");
			System.out.println("Ten cua ban :" + HoVaTen);
			System.out.println("Tuoi cua ban:" + tuoi);
			System.out.println("Ma sinh vien:" + MSV);
			System.out.println("Diem thi:" + Diem);
			System.out.println("-------------");
		}
}

