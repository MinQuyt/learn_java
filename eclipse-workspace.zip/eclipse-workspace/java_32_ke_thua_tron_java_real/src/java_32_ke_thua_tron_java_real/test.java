package java_32_ke_thua_tron_java_real;

public class test {
public static void main(String[] args) {
	ConNguoi nguoi1 = new ConNguoi("Tran Minh Quy", 2003);
	ConNguoi nguoi2 = new ConNguoi("Pham Mai Huong", 2003);
	
	HocSinh hocsinh1 = new HocSinh("Trần Minh Quý", 2003, "CNTT K!%-04","DaiNam");
	HocSinh hocsinh2 = new HocSinh("Pham Mai Hương", 2003, "TKDH", "FPT Polipepnic");
	 hocsinh1.an(); 
	 hocsinh1.uong();
	 hocsinh1.ngu();
	 hocsinh1.lamBaiTap();
}
}
