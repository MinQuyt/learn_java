package hoc_tren_lop;

import java.util.Scanner;

public class thao_tac_voi_chuoi {
public static void main(String[] args) {
	Scanner sc =new Scanner(System.in);
	String s1, s2;
	System.out.println("Nhap 2 chuoi cha v� con :");
	s1 = sc.next();
	s2 = sc.next();
	System.out.println();
	
}
}