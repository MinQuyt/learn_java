package hoc_tren_lop;

public class hoctap {
public static void main(String[] args) {
	System.out.println("Hello Word!");
}
}
