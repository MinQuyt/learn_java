package hoc_tren_lop;

import java.util.Scanner;

public class tong_cac_chu_so {
public static void main(String[] args) {
	int s=0;
	int n;
	System.out.println("Nhap n :");
	Scanner sc = new Scanner(System.in);
	n = sc.nextInt();
	while(n>0) {
		s+=n%10;
		n/=10;
	}
System.out.println("tong cac chu so nua n:"+s);	
}
}