package keThua;

import java.util.Scanner;

public class test {
	public static void main(String[] args) {
	System.out.println("nhap cạnh cho hinh vuong:");
	Scanner sc = new Scanner(System.in);
	int rong = sc.nextInt();
	HinhLapPhuong hlp = new HinhLapPhuong(rong, rong, rong);
	hlp.chuvi();
	System.out.println("dientich="+hlp.dientich());
	System.out.println("the tich="+hlp.theTich());
}
}
