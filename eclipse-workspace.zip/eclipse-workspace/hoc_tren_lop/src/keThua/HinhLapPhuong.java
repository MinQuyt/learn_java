package keThua;

public class HinhLapPhuong extends HinhVuong {
private int chieucao;

public HinhLapPhuong(int dai, int rong, int chieucao) {
	super(dai, rong);
	this.chieucao = chieucao;
}

public int getChieucao() {
	return chieucao;
}

public void setChieucao(int chieucao) {
	this.chieucao = chieucao;
}
public int theTich() {
	return dientich()*this.chieucao;
}
}
