package keThua;

public class HinhVuong {
private int dai , rong;

public HinhVuong(int dai, int rong) {
	this.dai = dai;
	this.rong = rong;
}

public int getDai() {
	return dai;
}

public void setDai(int dai) {
	this.dai = dai;
}

public int getRong() {
	return rong;
}

public void setRong(int rong) {
	this.rong = rong;
}
public void chuvi() {
	System.out.println("chuvi="+(this.dai+this.rong)*2);
}
public int dientich() {
	return this.dai*this.rong;
}
}
