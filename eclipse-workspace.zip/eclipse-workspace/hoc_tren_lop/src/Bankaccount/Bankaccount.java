package Bankaccount;

public class Bankaccount {
private String tenchutaikhoan;
private int sotien;
private String PhuongThucThanhToan;
	public Bankaccount(String ten , int st , String pttt) {
		this.tenchutaikhoan = ten ;
		this.sotien = st;
		this.PhuongThucThanhToan = pttt;
	}
public void hienthi() {
	System.out.println("ten chu khoan :"+this.tenchutaikhoan);
	System.out.println("so tien:"+this.sotien);
	System.out.println("Phương thức thanh toán :"+this.PhuongThucThanhToan);
}
}
