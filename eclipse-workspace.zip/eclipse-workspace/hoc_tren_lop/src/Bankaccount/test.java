package Bankaccount;

import java.util.Scanner;

public class test {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Nhap tên chu tai khoan , so tiền và phương thức thanh toán:");
	String tenchutaikhoan = sc.nextLine();
	int sotien = sc.nextInt();
	String PhuongThucThanhToan = sc.nextLine();
	Bankaccount bc = new Bankaccount(tenchutaikhoan, sotien, PhuongThucThanhToan);
	bc.hienthi();
}
}
