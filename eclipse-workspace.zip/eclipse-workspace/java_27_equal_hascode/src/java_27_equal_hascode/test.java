package java_27_equal_hascode;

import java.util.Scanner;

public class test {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int d , m ,y;
	System.out.println("Nhập ngày , tháng , năm :");
	d=sc.nextInt();
	m= sc.nextInt();
	y = sc.nextInt();
	MyDate md1 = new MyDate(d, m, y);
	MyDate md2 = new MyDate(16, 5, 2003);
	System.out.println(md1);
	System.out.println("Nhap ngày , tháng , năm muốn thay đổi:");
	d=sc.nextInt();
	m= sc.nextInt();
	y = sc.nextInt();
	md1.setDay(d);
	md1.setMonth(m);
	md1.setYear(y);
	System.out.println("md1:"+md1);
	System.out.println("md2:"+md2);
	System.out.println("md1 so sánh với md2:"+md1.equals(md2));
	System.out.println("Hascode của md1:"+md1.hashCode());
}
}
