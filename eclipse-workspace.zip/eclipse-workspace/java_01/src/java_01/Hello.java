package java_01;
public class Hello {
	//gõ main sau đó ctrl+space -> enter thì nó tự ra hàm main bên dưới
      public static void main(String[] args) {
    //gõ sysout sau đó ctrl+space -> enter thì nó tự ra hàm system.out.printnl bên dưới , hàm system.out.printnl tương đương với hàm printf trong lập trình C
    //lưu ý cấu trúc trong java và C giống nhau tức là trong ngoặc () ta sử dụng dấu "" mới có thể chạy được kí tự mà mình muốn hiển thị được ra màn hình console ( như C ) 
    //Và cuối câu lệnh luôn luôn phải có dấu chấm phẩy ; 	  
		System.out.println("Xin chào ! , Tran Minh Quý");
	}
}
