package java_31_Quan_Ly_May_Tinh;

public class HangSanXuat {
private String ThongTinTenHang;
private QuocGia quocGia;
public HangSanXuat(String thongTinTenHang, QuocGia quocGia) {
	ThongTinTenHang = thongTinTenHang;
	this.quocGia = quocGia;
}
public String getThongTinTenHang() {
	return ThongTinTenHang;
}
public void setThongTinTenHang(String thongTinTenHang) {
	ThongTinTenHang = thongTinTenHang;
}
public QuocGia getQuocGia() {
	return quocGia;
}
public void setQuocGia(QuocGia quocGia) {
	this.quocGia = quocGia;
}

}
