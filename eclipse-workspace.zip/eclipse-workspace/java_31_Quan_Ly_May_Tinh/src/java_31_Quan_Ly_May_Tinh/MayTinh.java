package java_31_Quan_Ly_May_Tinh;

public class MayTinh {
private HangSanXuat hangSanXuat;
private NgaySanXuat ngay;
private double giaBan;
private int thoiGianBaoHanhTheoThang;
public MayTinh(HangSanXuat hangSanXuat, NgaySanXuat ngay, double giaBan, int thoiGianBaoHanhTheoThang) {
	this.hangSanXuat = hangSanXuat;
	this.ngay = ngay;
	this.giaBan = giaBan;
	this.thoiGianBaoHanhTheoThang = thoiGianBaoHanhTheoThang;
}
public HangSanXuat getHangSanXuat() {
	return hangSanXuat;
}
public void setHangSanXuat(HangSanXuat hangSanXuat) {
	this.hangSanXuat = hangSanXuat;
}
public NgaySanXuat getNgay() {
	return ngay;
}
public void setNgay(NgaySanXuat ngay) {
	this.ngay = ngay;
}
public double getGiaBan() {
	return giaBan;
}
public void setGiaBan(double giaBan) {
	this.giaBan = giaBan;
}
public int getThoiGianBaoHanhTheoThang() {
	return thoiGianBaoHanhTheoThang;
}
public void setThoiGianBaoHanhTheoThang(int thoiGianBaoHanhTheoThang) {
	this.thoiGianBaoHanhTheoThang = thoiGianBaoHanhTheoThang;
}
public boolean kiemTraGiaThapHon(MayTinh maykhac) {
	return this.giaBan < maykhac.giaBan;
}
public String tenQuocGiaSanXuatMayTinh() {
	return this.hangSanXuat.getQuocGia().getTenQuocGia();
}
public double GiamGiachosinhvien(double x) {
	return this.giaBan-(this.giaBan*x/100);
}
}
