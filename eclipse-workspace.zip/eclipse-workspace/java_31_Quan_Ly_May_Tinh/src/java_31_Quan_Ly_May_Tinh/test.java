package java_31_Quan_Ly_May_Tinh;

public class test {
public static void main(String[] args) {
	NgaySanXuat ngay1 = new NgaySanXuat(16, 6, 2014);
	NgaySanXuat ngay2 = new NgaySanXuat(17, 2, 2013);
	NgaySanXuat ngay3 = new NgaySanXuat(26, 6, 2018);
	
	QuocGia quocgia1 = new QuocGia("VN", "Việt Nam");
	QuocGia quocgia2 = new QuocGia("JP", "Nhật Bản");
	QuocGia quocgia3 = new QuocGia("KR", "Hàn Quốc");
	
	HangSanXuat hang1 = new HangSanXuat("VinGroup", quocgia1);
	HangSanXuat hang2 = new HangSanXuat("Fujitsu", quocgia2);
	HangSanXuat hang3 = new HangSanXuat("Sony", quocgia3);
	
	MayTinh may1 = new MayTinh(hang1, ngay1, 15000, 12);
	MayTinh may2 = new MayTinh(hang2, ngay2, 30000, 24);
	MayTinh may3 = new MayTinh(hang3, ngay3, 55000, 12);
	
	System.out.println("Kiểm tra giá máy 1 có thấp hơn máy 2 không:"+may1.kiemTraGiaThapHon(may2));
	System.out.println("Kiem tra giá máy 2 có thấp hơn máy 3 không:"+may2.kiemTraGiaThapHon(may3));
	System.out.println("Kiem tra giá máy 3 có thấp hơn máy 1 không:"+may3.kiemTraGiaThapHon(may1));

	System.out.println("Tên quốc gia sản xuất máy 1:"+may1.tenQuocGiaSanXuatMayTinh());
	System.out.println("Tên quốc gia sản xuất máy 2:"+may2.tenQuocGiaSanXuatMayTinh());
	System.out.println("Tên quốc gia sản xuất máy 3:"+may3	.tenQuocGiaSanXuatMayTinh());

	System.out.println("Giảm giá may1 10% cho sinh viên:"+may1.GiamGiachosinhvien(10));
	System.out.println("Giảm giá may2 20% cho sinh viên:"+may2.GiamGiachosinhvien(20));
	System.out.println("Giảm giá may3 15% cho sinh viên:"+may3.GiamGiachosinhvien(15));
}
}