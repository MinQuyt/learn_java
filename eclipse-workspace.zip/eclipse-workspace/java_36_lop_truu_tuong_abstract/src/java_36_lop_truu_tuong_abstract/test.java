package java_36_lop_truu_tuong_abstract;

public class test {
public static void main(String[] args) {
	ToaDo toado1 = new ToaDo(1, 1);
	ToaDo toado2 = new ToaDo(2, -3);
	
	HinhTron ht = new HinhTron(toado1 ,5);
	HinhChuNhat hcn = new HinhChuNhat(toado2, 4, 6);
	
	System.err.println("dien tich tron:"+ht.tinhDienTich());
	System.err.println("dien tich hcn:"+hcn.tinhDienTich());
}
}
