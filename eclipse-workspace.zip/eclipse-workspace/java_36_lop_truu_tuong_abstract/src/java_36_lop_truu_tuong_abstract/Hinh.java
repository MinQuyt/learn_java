package java_36_lop_truu_tuong_abstract;

public abstract class Hinh {
	//Gọi lại class cha : ToaDo
	protected ToaDo toaDo;
	//tọa constructor Hinh cho toa do vừa tạo trong ngoặc bằng với tọa độ của class cha
public Hinh(ToaDo toaDo) {
	this.toaDo = toaDo;
}	
public abstract  double tinhDienTich();
}

