package java_36_lop_truu_tuong_abstract;

public class HinhTron extends Hinh {
private double r;
	public HinhTron(ToaDo toaDo,double r) {
		super(toaDo);
		this.r = r;
		
	}
	@Override
	public double tinhDienTich() {
		return Math.PI*Math.pow(r, 2);
	}

}
