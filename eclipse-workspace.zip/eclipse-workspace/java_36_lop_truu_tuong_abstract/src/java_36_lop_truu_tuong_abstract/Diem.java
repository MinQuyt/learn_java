package java_36_lop_truu_tuong_abstract;

public class Diem extends Hinh{

	public Diem(ToaDo toaDo) {
		super(toaDo);
		
	}

	@Override
	public double tinhDienTich() {
return 1;		
	}

}
