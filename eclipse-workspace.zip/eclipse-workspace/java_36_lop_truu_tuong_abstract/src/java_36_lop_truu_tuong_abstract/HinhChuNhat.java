package java_36_lop_truu_tuong_abstract;

public class HinhChuNhat extends Hinh {
	private	double chieuRong;
	private	double chieuCao;
public HinhChuNhat(ToaDo toaDo,double chieuRong, double chieuCao) {
		super(toaDo);
		this.chieuCao = chieuCao;
		this.chieuRong = chieuRong;
	}
@Override
public double tinhDienTich() {
	return chieuCao*chieuRong;	
}
}
