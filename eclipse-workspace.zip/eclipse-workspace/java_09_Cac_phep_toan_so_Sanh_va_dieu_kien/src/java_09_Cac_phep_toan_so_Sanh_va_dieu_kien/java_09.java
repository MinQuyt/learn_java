package java_09_Cac_phep_toan_so_Sanh_va_dieu_kien;

import java.util.Scanner;

public class java_09 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	//Nhap dữ liệu
	System.out.println("Nhap a:");
	int a = sc.nextInt();
	System.out.println("Nhap b:");
	int b = sc.nextInt();
	//xu li du lieu
	System.out.println(a +"=="+ b + ":" + (a==b));
	System.out.println(a +">"+ b + ":" + (a>b));
	System.out.println(a +"<"+ b + ":" + (a<b));
	System.out.println(a +">="+ b + ":" + (a>=b));
	System.out.println(a +"<="+ b + ":" + (a<=b));
	System.out.println(a +"!="+ b + ":" + (a!=b));
	System.out.println("------------");
	System.out.println("Ca 2 deu la so duong " + (a%2==0 && b%2==0));
	System.out.println("Co it nhat 1 so duong "+ (a%2==0 || b%2==0));
	}
}
