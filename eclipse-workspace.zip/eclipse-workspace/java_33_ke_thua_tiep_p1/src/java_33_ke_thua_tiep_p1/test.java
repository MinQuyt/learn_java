package java_33_ke_thua_tiep_p1;

import java_33_ke_thua_tiep_p1.BabyDog;

public class test {
public static void main(String[] args) {
	BabyDog bbd = new BabyDog();
	bbd.eat();
	bbd.bark();
	bbd.weep();
}
}
