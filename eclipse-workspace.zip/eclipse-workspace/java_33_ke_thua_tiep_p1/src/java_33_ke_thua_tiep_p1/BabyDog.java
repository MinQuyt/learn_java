package java_33_ke_thua_tiep_p1;

import java_33_ke_thua_tiep_p1.Dog;

public class BabyDog extends Dog {
	public BabyDog() {
		super();
	}
	public void weep() {
		System.out.println("Ẳng Ẳng");
		
	}
}
