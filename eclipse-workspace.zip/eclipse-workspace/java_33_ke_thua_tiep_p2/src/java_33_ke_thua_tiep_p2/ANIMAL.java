package java_33_ke_thua_tiep_p2;

public class ANIMAL {
protected String name;

public ANIMAL(String name) {
	this.name = name;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
 public void eat() {
	 System.out.println("nhoàm nhoàm");
 }
}
