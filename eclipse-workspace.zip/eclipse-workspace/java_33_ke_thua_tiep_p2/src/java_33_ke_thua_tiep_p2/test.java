package java_33_ke_thua_tiep_p2;

public class test {
public static void main(String[] args) {
	Dog cho = new Dog();
	cho.eat();
	cho.bark();
}
}
