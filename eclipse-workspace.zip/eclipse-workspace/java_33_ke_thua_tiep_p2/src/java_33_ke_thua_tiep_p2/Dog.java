package java_33_ke_thua_tiep_p2;

public class Dog extends ANIMAL{

	public Dog() {
		super("Dog");
	}
	public void bark() {
		System.out.println("g�u g�u");
	}

}
