package on_tap;

import java.util.Scanner;

public class on_tap {
	public static void main(String[] args) {
		Scanner SV = new Scanner(System.in);
		System.out.println("Nhap ten sinh vien:");
		String Ten = SV.nextLine();
		System.out.println("Nhap tuoi");
		int tuoi = SV.nextInt();
		System.out.println("Nhap ma sinh vien:");
		long MSV = SV.nextLong();
		System.out.println("Nhap diem:");
		float Diem = SV.nextFloat();
		//xuat du lieu
		System.out.println("Ten sinh vien: "+ Ten);
		System.out.println("Tuoi: "+tuoi);
		System.out.println("MSV: "+MSV);
		System.out.println("Diem: "+Diem);
		//nhap bien hang so
		final double Pi = 3.14; // khai bao bien hang so
		// ep kieu trong java
		//ep kieu ngam dinh
		float a = tuoi;
		System.out.println("a= "+a);
		//ep kieu tuong minh
		int b = (int)a; 
		System.out.println("b= "+b);
		//ep kieu DL co ban va doi tuong
		int x = new Integer(tuoi);
		System.out.println("x= "+x);
	}
}

